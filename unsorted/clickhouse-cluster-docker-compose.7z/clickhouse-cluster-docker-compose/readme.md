# clickhouse cluster example in docker compose

## Usage

```
# Init and start
docker-compose up

# into clickhouse node bash
docker exec -it ch-server-11 /bin/bash
docker exec -it ch-server-12 /bin/bash
docker exec -it ch-server-21 /bin/bash
docker exec -it ch-server-22 /bin/bash
```
